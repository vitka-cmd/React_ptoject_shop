import { ICardObject } from "../../types/cardobject.type";

export const CardComponent = (object: ICardObject) => {
  console.log(object);//

  return (
    <>
      <div className="card"></div>
    </>
  );
};
