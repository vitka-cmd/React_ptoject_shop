export const CardListMainComponent = () => {
  return <></>;
};
