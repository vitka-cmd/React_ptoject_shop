import { CardListMainComponent } from "./CardList.main.component";

export const MainComponent = () => {
  return (
    <>
      <main>
        <CardListMainComponent />
      </main>
    </>
  );
};
