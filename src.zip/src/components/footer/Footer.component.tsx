export const FooterComponent = () => {
  return (
    <>
      <footer></footer>
    </>
  );
};
