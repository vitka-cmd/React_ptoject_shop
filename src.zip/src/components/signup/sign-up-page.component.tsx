import { useState} from "react";
import "./sign-up.css";
import { useNavigate } from "react-router";
import {
  handleOnFormSubmit,
  handleOnInputChange,
} from "../../controllers/sign-up.controllers";
import { IFormData } from "../../types";
// import { fetchData } from "../../api";

const SignUpComponent = () => {
  const [formData, setFormData] = useState<IFormData>({
    username: "",
    email: "",
    password: "",
  });
  const navigate = useNavigate()
    const handleOnSignUpButtonClick = () =>{

        navigate('/')
    }
  const [data, setData] = useState([]);
  const [isRegistered, setIsRegistered] = useState(false);
  console.log(data);

  return (
    <div className="registration">
      <form
        className="registration_block"
        onSubmit={(event) =>
          handleOnFormSubmit({ event, formData, setIsRegistered})//
        }
      >
        <h1>Регистрация</h1>
        <div>
          <label>Имя пользователя:</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={(event) =>
              handleOnInputChange({ event, formData, setFormData })
            }
            required
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={(event) =>
              handleOnInputChange({ event, formData, setFormData })
            }
            required
          />
        </div>
        <div>
          <label>Пароль:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={(event) =>
              handleOnInputChange({ event, formData, setFormData })
            }
            required
          />
        </div>
        <button type="submit" onClick={handleOnSignUpButtonClick}>Зарегистрироваться</button>
      </form>
    </div>
  );
};
export default SignUpComponent;
