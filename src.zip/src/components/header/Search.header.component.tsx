import "./header.css";

export const SearchHeaderComponent = () => {
  return (
    <>
      <div className="searchContainer">
        <input type="search" placeholder={"search"} />
        <button className="searchButton"></button>
      </div>
    </>
  );
};
