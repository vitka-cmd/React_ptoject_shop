import "./header.css";
import { SearchHeaderComponent } from "./Search.header.component";
import { AccountHeaderComponent } from "./Account.header.component";
import { CartButtonHeaderComponent } from "./CartButton.header.component";

export const MainHeaderComponent = () => {
  return (
    <>
      <header>
        <SearchHeaderComponent />
        <div className="mainContainer">
          <AccountHeaderComponent />
          <CartButtonHeaderComponent />
        </div>
      </header>
    </>
  );
};
