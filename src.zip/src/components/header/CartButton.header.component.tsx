import "./header.css";
export const CartButtonHeaderComponent = () => {
  return (
    <>
      <button className="cartButton"></button>
    </>
  );
};
