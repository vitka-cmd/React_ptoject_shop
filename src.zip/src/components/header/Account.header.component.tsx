import { useNavigate } from "react-router";


export const AccountHeaderComponent = () => {
  const navigate = useNavigate()
    const handleOnSignUpButtonClick = () =>{
      navigate('/registration')
    }
  return (
    <>
      <div onClick={handleOnSignUpButtonClick} className="accountCard">
        <div className="avatar"></div>
        <div className="accountdataContainer">
          <p className="accountdata">vewffqer</p>
          <p className="accountdata">vwrrw</p>
        </div>
      </div>
    </>
  );
};
