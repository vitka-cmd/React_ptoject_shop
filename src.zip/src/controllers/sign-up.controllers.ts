import axios from "axios";
import {
  IHandleOnFormSubmitProps,
  IHandleOnInputChangeProps,
} from "../types/sign-up.controllers.props";
export const handleOnInputChange = ({
  event,
  formData,
  setFormData,
}: IHandleOnInputChangeProps) => {
  setFormData({
    ...formData,
    [event.target.name]: event.target.value,
  });
};

export const handleOnFormSubmit = async ({
  event,
  formData,
  setIsRegistered,
}: IHandleOnFormSubmitProps) => {
  event.preventDefault();
  try {
    const response = await axios.post(
      "https://jsonplaceholder.typicode.com/users",
      formData
    );
    setIsRegistered(true);
    console.log("Регистрация успешна:", response.data);
    alert("Регистрация успешна!");
    
  } catch (error) {
    console.error("Ошибка регистрации:", error);
    alert("Ошибка регистрации!");
  }
};
