import React from "react";
import SignUpComponent from "../../components/signup/sign-up-page.component";
import { useNavigate } from "react-router";

export default function SignInPage(){
   return(
    <>
    <SignUpComponent></SignUpComponent>
    </>
   )
}