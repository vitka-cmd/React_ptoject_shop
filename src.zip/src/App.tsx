import { useSearchParams } from "react-router";
import "./App.css";
import { FooterComponent } from "./components/footer/Footer.component";
import { MainHeaderComponent } from "./components/header";
import { MainComponent } from "./components/main/Main.component";
function App() {
  const [searchParams] = useSearchParams();
  console.log(searchParams.get('name'));
  return (
    <>
      <MainHeaderComponent />
      <MainComponent />
      <FooterComponent /> 
    </>
  );
}

export default App;
