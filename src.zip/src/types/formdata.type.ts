export interface IFormData {
  username: string;
  email: string;
  password: string;
}
