export interface ICardObject {
  id: number;
}
