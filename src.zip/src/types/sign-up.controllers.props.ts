import { IFormData } from "./";

export interface IHandleOnInputChangeProps {
  event: React.ChangeEvent<HTMLInputElement>;
  formData: IFormData;
  setFormData: (formData: IFormData) => void;
}

export interface IHandleOnFormSubmitProps {
  event: React.FormEvent<HTMLFormElement>;
  formData: IFormData;
  setIsRegistered: (isRegistered: boolean) => void;
}
